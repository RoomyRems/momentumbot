"""Offline verification of the original, consumed two-request census failure."""
from datetime import datetime, timezone
import gzip
import io
import json
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import zipfile

from momentumbot.research import early_pullback_census_hosted_v02 as m
from run_offline_python_v13 import deny_external_io

root = Path('/workspace/scratch/fe5755b45005/momentumbot')
scratch, base = root.parent, root / m.BASE
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
facts = {'head': git('rev-parse', 'HEAD'), 'parent_commit': git('rev-parse', 'HEAD^'),
    'parent_tree': git('rev-parse', 'HEAD^^{tree}'), 'parents': git('show', '-s', '--format=%P', 'HEAD').split(),
    'changed_files': git('diff', '--name-status', 'HEAD^', 'HEAD').splitlines(),
    'clean': not git('status', '--porcelain', '--untracked-files=no')}
sys.addaudithook(deny_external_io)
meta = json.loads((scratch / 'census-v02-hosted-metadata.json').read_bytes())
run, jobs, live_ref = meta['run'], meta['jobs']['jobs'], meta['ref']
require, exact = m.require, m.exact
require(run['id'] == 34703172831 and run['run_attempt'] == 1 and run['event'] == 'push'
    and run['head_sha'] == 'ca88994846062a49a5fad224c06dc31e433323a0'
    and run['head_branch'] == 'phase-3-historical-snapshot' and run['status'] == 'completed'
    and run['conclusion'] == 'failure' and run['path'] == m.WORKFLOW_PATH
    and run['repository']['full_name'] == 'RoomyRems/momentumbot', 'wrong original failure run')
require(meta['jobs']['total_count'] == 2 and {j['name'] for j in jobs} == {'consume', 'capture'}, 'exact jobs required')
consume = next(j for j in jobs if j['name'] == 'consume')
capture = next(j for j in jobs if j['name'] == 'capture')
require(consume['conclusion'] == 'success' and all(s['conclusion'] == 'success' for s in consume['steps']), 'consume steps failed')
failed_steps = [s['name'] for s in capture['steps'] if s['conclusion'] == 'failure']
exact(failed_steps, ['Validate all gates then execute the bounded census once'], 'unexpected capture job failure')
for step in capture['steps']:
    expected = ('failure' if step['name'] == failed_steps[0] else 'skipped' if step['name'] ==
        'Post Run actions/setup-python@42375524e23c412d93fb67b49958b491fce71c38' else 'success')
    require(step['status'] == 'completed' and step['conclusion'] == expected, 'unexpected capture or cleanup step')
for job in jobs:
    require(job['head_sha'] == run['head_sha'] and job['run_id'] == run['id'] and job['status'] == 'completed', 'job lineage differs')

artifact_specs, files = {}, {}
for kind in ('consumption', 'linkage', 'capture'):
    name = f'early-pullback-census-hosted-v02-{kind}-34703172831-1'
    candidates = [a for a in meta['artifacts'] if a['name'] == name]
    require(len(candidates) == 1, 'exact artifact required')
    item = candidates[0]
    require(item['expired'] is False and item['workflow_run']['id'] == run['id']
        and item['workflow_run']['head_sha'] == run['head_sha'], 'artifact origin differs')
    raw = (base / f'hosted-{kind}.zip').read_bytes()
    require(len(raw) == item['size_in_bytes'] and 'sha256:' + m.sha(raw) == item['digest'], 'GitHub artifact digest differs')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        require(len(infos) == len({i.filename for i in infos}) and sum(i.file_size for i in infos) <= 4_000_000, 'unsafe inventory')
        require(all(re.fullmatch(r'[a-z0-9-]+(?:\.[a-z]+)?\.json', i.filename) and not i.is_dir()
            and stat.S_IFMT(i.external_attr >> 16) in (0, stat.S_IFREG) for i in infos), 'unsafe ZIP member')
        files[kind] = {i.filename: archive.read(i.filename) for i in infos}
    artifact_specs[kind] = {'file': f'hosted-{kind}.zip', 'id': item['id'], 'bytes': len(raw),
        'sha256': m.sha(raw), 'github_digest_verified': True, 'created_at': item['created_at']}
require(len(meta['artifacts']) == 3, 'unexpected artifact population')

preflight, linkage, captured = (files[k] for k in ('consumption', 'linkage', 'capture'))
require(set(preflight) == m.PREFLIGHT_FILES | {'preflight-inventory.json'}, 'preflight members differ')
require(set(linkage) == set(preflight) | {'current-ref.json', 'artifact-metadata.json', 'capture-link.json'}, 'linkage members differ')
for name, raw in preflight.items():
    require(linkage[name] == raw, 'preflight bytes differ across jobs')
contract, adapter_contract = m.validate_registration(root), m.adapter.validate_registration(root)
execution = m.base.frozen(root / m.EXECUTION_PATH)
capture_log = (scratch / 'census-v02-capture.log').read_text()
pins = set(re.findall(r'CENSUS_PREFLIGHT_SHA256: ([0-9a-f]{64})', capture_log))
ids = set(re.findall(r'CENSUS_PREFLIGHT_ARTIFACT_ID: ([0-9]+)', capture_log))
require(len(pins) == len(ids) == 1, 'independent job-output pins required')
env = {'GITHUB_SHA': run['head_sha'], 'GITHUB_RUN_ID': str(run['id']), 'GITHUB_RUN_ATTEMPT': '1',
    'GITHUB_REPOSITORY': 'RoomyRems/momentumbot', 'GITHUB_EVENT_NAME': 'push',
    'GITHUB_REF': 'refs/heads/phase-3-historical-snapshot', 'GITHUB_WORKFLOW_SHA': run['head_sha'],
    'GITHUB_WORKFLOW_REF': 'RoomyRems/momentumbot/' + m.WORKFLOW_PATH + '@refs/heads/phase-3-historical-snapshot',
    'CENSUS_PREFLIGHT_SHA256': next(iter(pins)), 'CENSUS_PREFLIGHT_ARTIFACT_ID': next(iter(ids))}
capture_step = next(s for s in capture['steps'] if s['name'] == failed_steps[0])
launch_time = m.stamp(capture_step['started_at'])
m.validate_execution(execution, contract, env, facts, launch_time)
artifact = next(a for a in meta['artifacts'] if a['id'] == int(env['CENSUS_PREFLIGHT_ARTIFACT_ID']))
exact(m.base.json_object(linkage['current-ref.json']), live_ref, 'observed permanent ref differs')
exact(m.base.json_object(linkage['artifact-metadata.json']), artifact, 'observed artifact metadata differs')
marker = m.verify_preflight(preflight, contract, adapter_contract, execution, env,
    m.base.json_object(preflight['runtime.json']), live_ref, artifact)

def sealed(raw):
    value = m.base.json_object(raw)
    m.base.verify_seal(value)
    return value
link = sealed(linkage['capture-link.json'])
inventory, report = sealed(captured['inventory.json']), sealed(captured['report.json'])
require(set(inventory['files']) == set(captured) - {'inventory.json'}, 'capture inventory population differs')
for name, spec in inventory['files'].items():
    exact(spec, {'bytes': len(captured[name]), 'sha256': m.sha(captured[name])}, 'capture member hash differs')
exact(m.base.json_object(captured['contract.json']), adapter_contract, 'adapter contract differs')
require(set(captured) == {'contract.json', 'report.json', 'inventory.json', '0000.intent.json', '0000.receipt.json',
    '0000.body.json', '0000.normalized.json', '0001.intent.json', '0001.receipt.json'}, 'exact two-request evidence required')
state = m.adapter.CensusState()
receipts, intents = [], []
for ordinal in (0, 1):
    intent = sealed(captured[f'{ordinal:04d}.intent.json'])
    receipt = sealed(captured[f'{ordinal:04d}.receipt.json'])
    request = state.next_request()
    exact(intent, m.seal({'contract_id': m.adapter.ID, 'ordinal': ordinal, 'request': request,
        'started_at': intent['started_at'], 'started_monotonic_ns': intent['started_monotonic_ns']}), 'request order differs')
    require(m.stamp(intent['started_at']) <= m.stamp(receipt['finished_at']), 'request clock differs')
    require(type(intent['started_monotonic_ns']) is int and intent['started_monotonic_ns'] >= 0, 'monotonic clock differs')
    expected = {'contract_id': m.adapter.ID, 'ordinal': ordinal, 'intent_sha256': intent['content_sha256'],
        'request_sha256': request['content_sha256'], 'finished_at': receipt['finished_at'],
        'status': 200, 'body_complete': True, 'body_bytes': receipt['body_bytes'], 'body_sha256': receipt['body_sha256'],
        'body_retained': ordinal == 0, 'normalized_sha256': None, 'error': 'invalid_payload' if ordinal else None}
    if ordinal == 0:
        raw = captured['0000.body.json']
        projection = m.adapter.project_body(request, raw)
        require(len(raw) == receipt['body_bytes'] and m.sha(raw) == receipt['body_sha256'], 'retained raw bytes differ')
        require(captured['0000.normalized.json'] == m.adapter.render(projection), 'taxonomy projection differs')
        expected['normalized_sha256'] = m.adapter.fingerprint(projection)
        state.accept(request, m.sha(raw), projection)
    else:
        require(receipt['body_bytes'] == 293790 and receipt['body_sha256'] ==
            'dc8021cfcf825daa590a3ff03cb2d03ad02a6cd47bef909ac8ad58ec284292af', 'original failed-body receipt differs')
        require(intent['started_monotonic_ns'] - intents[0]['started_monotonic_ns'] >= m.adapter.INTERVAL_NS, 'request pacing differs')
    exact(receipt, m.seal(expected), 'receipt fields differ')
    intents.append(intent)
    receipts.append(receipt)
exact(report, m.adapter.report(state, 2, {'ordinal': 1, 'reason': 'invalid_payload'}), 'failure report differs')
exact(link, m.seal({'contract_id': m.ID, 'consumption': marker,
    'preflight_inventory_sha256': env['CENSUS_PREFLIGHT_SHA256'],
    'capture_files': {name: {'bytes': len(captured[name]), 'sha256': m.sha(captured[name])} for name in ('report.json', 'inventory.json')},
    'failure': 'capture_failed', 'protocol_complete': False, 'provider_origin_independently_verified': False,
    **m.adapter.BOUNDARY}), 'failure linkage differs')
upload = next(s for s in consume['steps'] if s['name'] == 'Retain consumption before credential access')
require(m.stamp(artifact['created_at']) <= m.stamp(upload['completed_at']) <= launch_time
    <= m.stamp(intents[0]['started_at']) < m.stamp(capture_step['completed_at']), 'durable consumption ordering differs')
try:
    m.adapter.verify_archive(base / 'hosted-capture.zip', contract=adapter_contract,
        expected_bytes=artifact_specs['capture']['bytes'], expected_sha256=artifact_specs['capture']['sha256'],
        expected_inventory_sha256=link['capture_files']['inventory.json']['sha256'])
except ValueError as exc:
    require(str(exc) == 'complete page evidence missing', 'unexpected complete-verifier rejection')
else:
    raise ValueError('incomplete census incorrectly passed complete verification')

log_specs = {}
for name in ('capture', 'consume'):
    raw = (scratch / f'census-v02-{name}.log').read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    with (base / f'hosted-{name}.log.gz').open('xb') as out:
        out.write(compressed)
    log_specs[name] = {'raw_bytes': len(raw), 'raw_sha256': m.sha(raw),
        'compressed_bytes': len(compressed), 'compressed_sha256': m.sha(compressed)}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name in ('census-v02-hosted-metadata.json', 'verify_census_v02_hosted_failure.py',
                 'arm_census_billing_v02_once.py', 'finish_census_billing_v02_ci_audit.py'):
        raw = (scratch / name).read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(raw), 0o644
        archive.addfile(info, io.BytesIO(raw))
compressed = gzip.compress(buffer.getvalue(), mtime=0)
with (base / 'hosted-verification-tools.tar.gz').open('xb') as out:
    out.write(compressed)
proof = m.seal({'contract_id': m.ID, 'artifact_type': 'verified_consumed_hosted_census_failure',
    'observed_at': datetime.now(timezone.utc).isoformat(), 'failure_evidence_verified': True,
    'workflow_run_id': run['id'], 'workflow_url': run['html_url'], 'workflow_conclusion': 'failure',
    'workflow_run_attempt': 1, 'execution_commit': run['head_sha'], 'code_commit': execution['code_commit_sha'],
    'successful_code_ci_run_id': execution['successful_code_ci_run_id'], 'registration_sha256': contract['content_sha256'],
    'execution_sha256': execution['content_sha256'], 'consumption_ref': live_ref,
    'artifacts': artifact_specs, 'logs': log_specs, 'tool_archive_sha256': m.sha(compressed),
    'preflight_file_count': len(preflight), 'linkage_file_count': len(linkage), 'capture_file_count': len(captured),
    'independent_preflight_inventory_pin': env['CENSUS_PREFLIGHT_SHA256'],
    'durable_consumption_uploaded_before_first_request': True, 'exact_parent_ci_verified': True,
    'frozen_runtime_verified': True, 'provider_request_execution_evidence_verified': True,
    'actual_provider_requests': 2, 'automatic_retries': 0, 'http_statuses': [r['status'] for r in receipts],
    'type_dictionary_rows_reparsed': len(state.types), 'attempted_membership_date': m.adapter.DATES[0],
    'accepted_membership_pages': 0, 'completed_census_dates': 0, 'protocol_complete': False,
    'failure': report['failure'], 'failed_response_body_bytes_receipted': receipts[1]['body_bytes'],
    'failed_response_body_sha256_receipted': receipts[1]['body_sha256'],
    'failed_body_retained': False, 'failed_body_hash_independently_recomputed': False,
    'exact_payload_rejection_reason_recoverable': False,
    'complete_archive_verifier_rejected_partial': True,
    'estimated_incremental_api_cost_usd': '0.00', 'actual_billed_cost_usd': None,
    'account_entitlement_provider_verified': False, 'credit_balance_provider_verified': False,
    'new_capture_authority_remaining': False,
    'limitations': ['HTTP 200 does not prove subscription or billing terms',
        'the rejected membership body was not retained; no exact schema diagnosis is possible from its hash',
        'not_started in the frozen report means zero accepted pages, not zero HTTP attempts',
        'verified original workflow and bytes establish this failed attempt, not a complete universe or historical identity'],
    **m.adapter.BOUNDARY})
m.base.write_once(base / 'hosted-failure-verification.json', proof)
print(json.dumps({'verification_sha256': proof['content_sha256'], 'actual_requests': 2,
    'http_statuses': proof['http_statuses'], 'type_rows': len(state.types), 'completed_dates': 0,
    'failure': report['failure'], 'all_original_artifact_digests_verified': True}))
