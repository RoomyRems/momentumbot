"""Retain exact published-code CI observations for the unarmed launcher."""
import gzip
import json
from pathlib import Path
import re
import subprocess
from momentumbot.research import early_pullback_census_hosted_v02 as m

scratch = Path('/workspace/scratch/fe5755b45005')
root = scratch / 'momentumbot'
base = root / m.BASE
raw = (scratch / 'census-billing-v02-ci.log').read_bytes()
log = raw.decode()
metadata = json.loads((scratch / 'census-billing-v02-ci-metadata.json').read_bytes())
run = metadata['run']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tree = subprocess.check_output(['git', 'show', '-s', '--format=%T', 'HEAD'], cwd=root, text=True).strip()
if run['head_sha'] != head or run['status'] != 'completed' or run['conclusion'] != 'success':
    raise RuntimeError('exact published-code success required')
job = next(item for item in metadata['jobs'] if item['name'] == 'CI')['jobs'][0]
if job['conclusion'] != 'success' or any(s['conclusion'] != 'success' for s in job['steps']):
    raise RuntimeError('every CI step must succeed')
new_tests = [line for line in log.splitlines() if '(test_early_pullback_census_hosted_v02.' in line and line.rstrip().endswith('... ok')]
adapter_tests = [line for line in log.splitlines() if '(test_early_pullback_census_v01.' in line and line.rstrip().endswith('... ok')]
matches = re.findall(r'Ran 2725 tests in ([0-9.]+)s', log)
if len(new_tests) != 34 or len(adapter_tests) != 36 or len(matches) != 1 or 'OK (skipped=73)' not in log:
    raise RuntimeError('complete exact test evidence required')
if any(item['name'] == 'Early pullback census hosted v0.2' for item in metadata['jobs']):
    raise RuntimeError('unarmed workflow unexpectedly triggered')
for item in metadata['jobs']:
    if item['name'] != 'CI':
        for j in item['jobs']:
            if j['conclusion'] != ('skipped' if j['name'] in ('probe', 'acquire') else 'success'):
                raise RuntimeError('legacy validation boundary differs')
compressed = gzip.compress(raw, mtime=0)
with (base / 'hosted-ci.log.gz').open('xb') as handle:
    handle.write(compressed)
result = m.seal({'contract_id': m.ID, 'artifact_type': 'hosted_launcher_implementation_verification',
    'code_commit': head, 'code_tree': tree, 'registration_sha256': m.validate_registration(root)['content_sha256'],
    'workflow_run_id': run['id'], 'workflow_url': run['html_url'], 'job_id': job['id'],
    'status': 'completed', 'conclusion': 'success', 'steps': job['steps'],
    'tests_run': 2725, 'passed': 2652, 'optional_sdk_skips': 73, 'failures': 0, 'errors': 0,
    'new_launcher_tests_passed': 34, 'adapter_tests_passed': 36, 'test_seconds': float(matches[0]),
    'dependency_install_lines': [line for line in log.splitlines() if 'Successfully installed' in line],
    'compressed_log_bytes': len(compressed), 'compressed_log_sha256': m.sha(compressed),
    'uncompressed_log_bytes': len(raw), 'uncompressed_log_sha256': m.sha(raw),
    'legacy_jobs': [{'run_id': item['run_id'], 'name': item['name'],
                    'jobs': [{'id': j['id'], 'name': j['name'], 'conclusion': j['conclusion']} for j in item['jobs']]}
                   for item in metadata['jobs'] if item['name'] != 'CI'],
    'census_execution_workflow_triggered': False, 'historical_baseline_replayed': False,
    'actual_provider_requests': 0, **m.adapter.BOUNDARY})
m.base.write_once(base / 'hosted-ci-verification.json', result)
print(json.dumps({'verification_sha256': result['content_sha256'], 'code_commit': head,
                  'run_id': run['id'], 'test_seconds': result['test_seconds'], 'tests_run': 2725, 'skips': 73}))
