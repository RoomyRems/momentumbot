"""Materialize the already approved, sole-file census child after exact code CI."""
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import subprocess
from momentumbot.research import early_pullback_census_hosted_v02 as m

root = Path('/workspace/scratch/fe5755b45005/momentumbot')
scratch = root.parent
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
if git('status', '--porcelain', '--untracked-files=no'):
    raise RuntimeError('clean tested parent required')
contract = m.validate_registration(root)
ci = json.loads((scratch / 'census-billing-v02-ci-metadata.json').read_bytes())
run = ci['run']
head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
if head != '583848a3585801a1966f0ef6aa200d7a2053a805' or run['head_sha'] != head:
    raise RuntimeError('exact tested code parent required')
proof = m.base.frozen(root / m.BASE / 'hosted-ci-verification.json')
if proof['code_commit'] != head or proof['tests_run'] != 2725 or proof['new_launcher_tests_passed'] != 34:
    raise RuntimeError('verified full code CI evidence required')
now = datetime.now(timezone.utc)
approval = {'approved_at': now.isoformat(), 'expires_at': (now + timedelta(days=1)).isoformat(),
    # Approval pointers hash the compact record projection; registration separately
    # binds each pretty-printed source file's exact raw bytes.
    'approval_record_sha256': m.sha(m.adapter.render(m.base.frozen(root / m.APPROVAL_SOURCE_PATH))),
    'pricing_record_sha256': m.sha(m.adapter.render(m.base.frozen(root / m.PRICING_PATH))),
    'approved_by': 'repository_owner', 'statement': m.APPROVAL_TEXT,
    'entitlement_basis': 'public_documented_basic_plan_inclusion',
    'subscription_coverage_owner_attested': False, 'entitlement_is_provider_verified': False,
    'credit_balance_provider_verified': False,
    'provider': 'Massive', 'credential_name': 'MASSIVE_API_KEY',
    'routes': [m.adapter.parent.CENSUS_ROUTE, m.adapter.type_request()['url']],
    'selected_dates': list(m.adapter.DATES), 'maximum_requests': 601,
    'maximum_authorized_incremental_cost_usd': '10.00', 'estimated_incremental_api_cost_usd': '0.00',
    'provider_billing_cap_enforced': False, 'metered_purchase_authorized': False,
    'subscription_changes_authorized': False}
execution = m.execution_payload(contract, code_commit=head, code_tree=tree,
    ci_run_id=str(run['id']), approval=approval, now=now)
jobs = next(item['jobs'] for item in ci['jobs'] if item['name'] == 'CI')
m.validate_ci(run, {'total_count': len(jobs), 'jobs': jobs}, execution)
m.base.write_once(root / m.EXECUTION_PATH, execution)
print(json.dumps({'execution_sha256': execution['content_sha256'], 'parent': head,
                  'code_ci': run['id'], 'scope': m.APPROVAL_TEXT, 'approval_recorded_at': approval['approved_at']}))
