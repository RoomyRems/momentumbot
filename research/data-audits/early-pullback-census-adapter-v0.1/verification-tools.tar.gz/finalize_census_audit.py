"""Write-once generated mechanics evidence; never calls a provider."""
import gzip
import io
import json
from pathlib import Path
import sys
import tarfile

scratch = Path('/workspace/scratch/fe5755b45005')
root = scratch / 'momentumbot'
sys.path.insert(0, str(root / 'tests'))
from run_offline_python_v13 import deny_external_io
sys.addaudithook(deny_external_io)
from momentumbot.research import early_pullback_census_v01 as m
from test_early_pullback_census_v01 import session, archive_files

base = root / m.BASE
contract = m.validate_registration(root)
checks = {}
logs = {}
for phase in ('focused', 'optimized', 'full'):
    raw = (scratch / f'census-{phase}-tests.log').read_bytes()
    completion = json.loads((scratch / f'census-{phase}-completion.json').read_bytes())
    if not completion['successful'] or completion['failures'] or completion['errors']:
        raise RuntimeError('failed checks cannot be finalized as successful')
    expected = 2661 if phase == 'full' else 36
    if completion['tests_run'] != expected or completion['discovered'] != expected:
        raise RuntimeError('incomplete inventory')
    suffix = b'OK (skipped=73)\n' if phase == 'full' else b'OK\n'
    if not raw.endswith(suffix):
        raise RuntimeError('terminal log receipt missing')
    compressed = gzip.compress(raw, mtime=0)
    name = f'{phase}-tests.log.gz'
    with (base / name).open('xb') as handle:
        handle.write(compressed)
    checks[phase] = completion
    logs[name] = {'bytes': len(compressed), 'sha256': m.sha(compressed),
                  'uncompressed_bytes': len(raw), 'uncompressed_sha256': m.sha(raw)}

instance, clock = session(scratch / 'census-synthetic-capture', contract=contract)
report = instance.run()
files = {p.name: p.read_bytes() for p in instance.store.path.iterdir()}
archive = base / 'synthetic-capture.zip'
pins = archive_files(archive, files)
verified = m.verify_archive(archive, contract=contract, **pins)
m.parent.parent.write_once(base / 'synthetic-verification.json', m.seal({
    'artifact_type': 'synthetic_mechanics_fixture_verification',
    'fixture': 'invented SYNTH membership; fake clock; injected in-memory transport; no HTTP',
    'registration_sha256': contract['content_sha256'], 'archive_pins': pins,
    'result': verified, 'provider_requests': 0, 'market_observations': False,
    'time_spacing_seconds': clock.sleeps}))
verification = m.seal({'contract_id': m.ID, 'artifact_type': 'local_implementation_verification',
    'registration_sha256': contract['content_sha256'], 'checks': checks, 'logs': logs,
    'synthetic_verification_sha256': m.parent.parent.frozen(base / 'synthetic-verification.json')['content_sha256'],
    'prior_development_check': 'pre-freeze-check.json',
    'verification_runner_sha256': m.sha((scratch / 'run_census_checks.py').read_bytes()),
    'historical_baseline_replayed': False, 'actual_provider_requests': 0,
    'hosted_ci_status': 'not yet run; tracked separately', **m.BOUNDARY})
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive_tools:
    for name in ('run_census_checks.py', 'finalize_census_audit.py'):
        raw = (scratch / name).read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        archive_tools.addfile(info, io.BytesIO(raw))
compressed_tools = gzip.compress(buffer.getvalue(), mtime=0)
with (base / 'verification-tools.tar.gz').open('xb') as handle:
    handle.write(compressed_tools)
verification.pop('content_sha256')
verification['verification_tools_archive_sha256'] = m.sha(compressed_tools)
verification = m.seal(verification)
m.parent.parent.write_once(base / 'implementation-verification.json', verification)
print(json.dumps({'verification_sha256': verification['content_sha256'], 'checks': checks,
                  'synthetic_archive': pins, 'verified_members': verified['verified_member_count']}, sort_keys=True))
