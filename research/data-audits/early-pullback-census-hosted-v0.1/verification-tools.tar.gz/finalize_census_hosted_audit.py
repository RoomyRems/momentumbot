"""Write-once offline verification evidence; synthetic authority is not consent."""
import gzip
import io
import json
from pathlib import Path
import sys
import tarfile

scratch = Path('/workspace/scratch/fe5755b45005')
root = scratch / 'momentumbot'
sys.path.insert(0, str(root))
from run_offline_python_v13 import deny_external_io
sys.addaudithook(deny_external_io)
from momentumbot.research import early_pullback_census_hosted_v01 as m
from tests.test_early_pullback_census_hosted_v01 import HostedCensusTests
from tests.test_early_pullback_census_v01 import archive_files

base = root / m.BASE
contract = m.validate_registration(root)
checks, logs = {}, {}
for phase in ('focused', 'optimized', 'full'):
    attempt = 'full-retry' if phase == 'full' else phase
    raw = (scratch / f'census-hosted-{attempt}-tests.log').read_bytes()
    completion = json.loads((scratch / f'census-hosted-{attempt}-completion.json').read_bytes())
    expected = 2691 if phase == 'full' else 66
    if not completion['successful'] or completion['tests_run'] != expected or completion['discovered'] != expected or completion['failures'] or completion['errors']:
        raise RuntimeError('complete successful inventory required')
    if not raw.endswith(b'OK (skipped=73)\n' if phase == 'full' else b'OK\n'):
        raise RuntimeError('terminal receipt required')
    compressed = gzip.compress(raw, mtime=0)
    with (base / f'{phase}-tests.log.gz').open('xb') as handle:
        handle.write(compressed)
    checks[phase] = completion
    logs[phase] = {'compressed_bytes': len(compressed), 'compressed_sha256': m.sha(compressed),
                   'raw_bytes': len(raw), 'raw_sha256': m.sha(raw)}

HostedCensusTests.setUpClass()
fixture = HostedCensusTests()
fixture.setUp()
try:
    files = fixture.prepare()
    marker = fixture.verify(files)
    result = fixture.run_capture(files)
    capture_dir = fixture.root / 'result' / 'capture'
    capture_files = {p.name: p.read_bytes() for p in capture_dir.iterdir()}
    path = base / 'synthetic-capture.zip'
    pins = archive_files(path, capture_files)
    checked = m.adapter.verify_archive(path, contract=fixture.adapter_contract, **pins)
    linkage = m.base.frozen(fixture.root / 'result' / 'launch' / 'capture-link.json')
    if linkage['capture_files']['inventory.json']['sha256'] != pins['expected_inventory_sha256']:
        raise RuntimeError('capture/linkage mismatch')
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w') as archive:
        for item in sorted((fixture.root / 'result').rglob('*.json')):
            raw = item.read_bytes()
            info = tarfile.TarInfo(str(item.relative_to(fixture.root / 'result')))
            info.size, info.mode = len(raw), 0o644
            archive.addfile(info, io.BytesIO(raw))
    compressed = gzip.compress(buffer.getvalue(), mtime=0)
    with (base / 'synthetic-launch.tar.gz').open('xb') as handle:
        handle.write(compressed)
    synthetic = m.seal({'contract_id': m.ID, 'artifact_type': 'synthetic_launch_mechanics_verification',
        'synthetic_authority_only': True, 'git_checkout_facts_are_fixture': True,
        'registration_loaders_mocked_for_fixture': True, 'transport_and_clock_are_fixture': True,
        'owner_approval_obtained': False, 'subscription_entitlement_confirmed': False,
        'actual_provider_requests': 0, 'registration_sha256': contract['content_sha256'],
        'preflight_file_count': len(files), 'consumption_sha256': marker['content_sha256'],
        'capture_link_sha256': linkage['content_sha256'], 'capture_archive_pins': pins,
        'capture_verification': checked, 'synthetic_launch_tar_sha256': m.sha(compressed),
        **m.adapter.BOUNDARY})
    m.base.write_once(base / 'synthetic-verification.json', synthetic)
finally:
    fixture.doCleanups()

buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name in ('run_census_hosted_checks.py', 'finalize_census_hosted_audit.py'):
        raw = (scratch / name).read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(raw), 0o644
        archive.addfile(info, io.BytesIO(raw))
compressed = gzip.compress(buffer.getvalue(), mtime=0)
with (base / 'verification-tools.tar.gz').open('xb') as handle:
    handle.write(compressed)
verification = m.seal({'contract_id': m.ID, 'artifact_type': 'local_launcher_implementation_verification',
    'registration_sha256': contract['content_sha256'], 'bound_files': len(contract['file_bindings']),
    'checks': checks, 'logs': logs, 'verification_tools_sha256': m.sha(compressed),
    'synthetic_verification_sha256': synthetic['content_sha256'],
    'execution_file_present': (root / m.EXECUTION_PATH).exists(), 'actual_provider_requests': 0,
    'historical_baseline_replayed': False, 'hosted_ci_status': 'not yet run; separate evidence follows', **m.adapter.BOUNDARY})
if verification['execution_file_present']:
    raise RuntimeError('unarmed publication required')
m.base.write_once(base / 'implementation-verification.json', verification)
print(json.dumps({'verification_sha256': verification['content_sha256'], 'bound_files': verification['bound_files'],
                  'checks': checks, 'synthetic_capture_verified_files': checked['verified_member_count']}, sort_keys=True))
