"""Bounded offline launcher checks with exact inventory and terminal receipts."""
import json
from pathlib import Path
import sys
import time
import unittest

scratch = Path('/workspace/scratch/fe5755b45005')
sys.path.insert(0, str(scratch / 'momentumbot'))
import numpy
import pandas

phase = sys.argv[1]
if phase not in {'focused', 'optimized', 'full'}:
    raise RuntimeError('unknown check')
if phase != 'focused' and (pandas.__version__, numpy.__version__) != ('3.0.5', '2.5.3'):
    raise RuntimeError('exact existing alternative environment required')
started = time.monotonic()
suite = unittest.defaultTestLoader.discover('tests', pattern='test*.py' if phase == 'full' else 'test_early_pullback_census*.py')
discovered = suite.countTestCases()
expected = 2691 if phase == 'full' else 66
if discovered != expected or unittest.defaultTestLoader.errors:
    raise RuntimeError('exact complete test inventory required')
print(json.dumps({'phase': phase, 'discovered': discovered, 'import_errors': 0,
                  'pandas': pandas.__version__, 'numpy': numpy.__version__}), flush=True)
with (scratch / f'census-hosted-{phase}-tests.log').open('x') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
summary = {'phase': phase, 'discovered': discovered, 'tests_run': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors),
    'skips': len(result.skipped), 'expected_failures': len(result.expectedFailures),
    'unexpected_successes': len(result.unexpectedSuccesses), 'optimize': sys.flags.optimize,
    'successful': result.wasSuccessful(), 'elapsed_seconds': time.monotonic() - started,
    'pandas': pandas.__version__, 'numpy': numpy.__version__}
with (scratch / f'census-hosted-{phase}-completion.json').open('x') as handle:
    json.dump(summary, handle, sort_keys=True, indent=2)
    handle.write('\n')
print(json.dumps(summary, sort_keys=True))
sys.exit(0 if result.wasSuccessful() and result.testsRun == discovered else 1)
