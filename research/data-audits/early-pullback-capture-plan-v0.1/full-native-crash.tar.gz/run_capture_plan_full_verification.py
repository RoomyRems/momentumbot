"""Full unittest inventory with a dedicated stream and durable terminal receipt."""
import faulthandler
import json
from pathlib import Path
import sys
import time
import unittest

scratch = Path('/workspace/scratch/fe5755b45005')
sys.path.insert(0, str(scratch / 'momentumbot'))
started = time.monotonic()
with (scratch / 'capture-plan-full-verified-stacks.log').open('x') as stacks:
    faulthandler.dump_traceback_later(60, repeat=True, file=stacks)
    suite = unittest.defaultTestLoader.discover('tests')
    discovered = suite.countTestCases()
    if discovered != 2625 or unittest.defaultTestLoader.errors:
        raise RuntimeError('complete 2625-test inventory required before execution')
    print(json.dumps({'discovered': discovered, 'import_errors': 0}), flush=True)
    with (scratch / 'capture-plan-full-verified-tests.log').open('x') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    faulthandler.cancel_dump_traceback_later()
    summary = {'discovered': discovered, 'tests_run': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors),
        'skips': len(result.skipped), 'expected_failures': len(result.expectedFailures),
        'unexpected_successes': len(result.unexpectedSuccesses),
        'successful': result.wasSuccessful(), 'elapsed_seconds': time.monotonic() - started}
    with (scratch / 'capture-plan-full-verified-completion.json').open('x') as handle:
        json.dump(summary, handle, sort_keys=True, indent=2)
        handle.write('\n')
    print(json.dumps(summary, sort_keys=True))
    sys.exit(0 if result.wasSuccessful() and result.testsRun == discovered else 1)
